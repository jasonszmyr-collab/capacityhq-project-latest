import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import {
  configureDeviceState,
  submitDirectives,
  getDeviceStatus,
  type DeviceStatusResponse,
  type ArduinoStatus,
} from '../mobile/services/flagApi';
import type { Directive } from '../mobile/services/directiveApi';
import { getDirectives } from '../mobile/services/directiveApi';

export default function FlagControlTest() {
  const [stateCode, setStateCode] = useState('CA');
  const [deviceStatus, setDeviceStatus] = useState<DeviceStatusResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Federal directive form
  const [federalActive, setFederalActive] = useState(false);
  const [federalExpires, setFederalExpires] = useState('');
  const [federalReason, setFederalReason] = useState('');

  // State directive form
  const [stateActive, setStateActive] = useState(false);
  const [stateExpires, setStateExpires] = useState('');
  const [stateReason, setStateReason] = useState('');

  // Auto-refresh status
  useEffect(() => {
    const interval = setInterval(() => {
      fetchDeviceStatus();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const fetchDeviceStatus = async () => {
    try {
      const status = await getDeviceStatus();
      setDeviceStatus(status);
    } catch (err) {
      console.error('Failed to fetch status:', err);
    }
  };

  const handleConfigureDevice = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const result = await configureDeviceState(stateCode);
      setSuccess(`Device configured: ${result.message}`);
      await fetchDeviceStatus();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to configure device');
    } finally {
      setLoading(false);
    }
  };

  const handleFetchDirectives = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const directives = await getDirectives(stateCode);

      if (directives.federal) {
        setFederalActive(directives.federal.requiresHalf);
        setFederalExpires(new Date(directives.federal.expiresAt * 1000).toISOString().slice(0, 16));
        setFederalReason(directives.federal.reason);
      }

      if (directives.state) {
        setStateActive(directives.state.requiresHalf);
        setStateExpires(new Date(directives.state.expiresAt * 1000).toISOString().slice(0, 16));
        setStateReason(directives.state.reason);
      }

      setSuccess('Directives fetched successfully');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch directives');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitDirectives = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const federal: Directive | null = federalActive ? {
        valid: true,
        requiresHalf: true,
        expiresAt: Math.floor(new Date(federalExpires).getTime() / 1000),
        authority: 'Federal',
        jurisdiction: 'FEDERAL',
        reason: federalReason,
      } : null;

      const state: Directive | null = stateActive ? {
        valid: true,
        requiresHalf: true,
        expiresAt: Math.floor(new Date(stateExpires).getTime() / 1000),
        authority: 'State',
        jurisdiction: `STATE:${stateCode}`,
        reason: stateReason,
      } : null;

      const result = await submitDirectives(federal, state);
      setSuccess(`Directives submitted: ${result.message}`);
      await fetchDeviceStatus();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit directives');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: ArduinoStatus): string => {
    switch (status) {
      case 'ENFORCED':
        return 'bg-green-500';
      case 'DENIED_REQUEST':
        return 'bg-red-500';
      case 'IDLE':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Flag Position Control Test</h1>
          <p className="text-gray-600">Test the Base44 API for flag position control</p>
        </div>

        {error && (
          <Alert className="mb-6 bg-red-50 border-red-200">
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration Section */}
          <Card>
            <CardHeader>
              <CardTitle>Device Configuration</CardTitle>
              <CardDescription>Configure the device state location</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="stateCode">State Code</Label>
                <Input
                  id="stateCode"
                  value={stateCode}
                  onChange={(e) => setStateCode(e.target.value.toUpperCase())}
                  placeholder="CA"
                  maxLength={2}
                />
              </div>
              <Button onClick={handleConfigureDevice} disabled={loading} className="w-full">
                Configure Device
              </Button>
            </CardContent>
          </Card>

          {/* Status Display */}
          <Card>
            <CardHeader>
              <CardTitle>Device Status</CardTitle>
              <CardDescription>Real-time device state (auto-refresh every 5s)</CardDescription>
            </CardHeader>
            <CardContent>
              {deviceStatus ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Arduino Status:</span>
                    <Badge className={getStatusColor(deviceStatus.status.arduinoStatus)}>
                      {deviceStatus.status.arduinoStatus}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Device State:</span>
                    <span className="text-sm">{deviceStatus.status.deviceState || 'Not configured'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Current Position:</span>
                    <span className="text-sm">{deviceStatus.status.currentPosition || 'Unknown'}</span>
                  </div>
                  {deviceStatus.status.explanation && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-900">{deviceStatus.status.explanation}</p>
                    </div>
                  )}
                  {deviceStatus.status.federalDirective && (
                    <div className="mt-4 p-3 bg-purple-50 rounded-md">
                      <p className="text-xs font-semibold text-purple-900 mb-1">Federal Directive</p>
                      <p className="text-sm text-purple-800">
                        Active: {deviceStatus.status.federalDirective.active ? 'Yes' : 'No'}
                      </p>
                      {deviceStatus.status.federalDirective.reason && (
                        <p className="text-sm text-purple-800 mt-1">
                          {deviceStatus.status.federalDirective.reason}
                        </p>
                      )}
                    </div>
                  )}
                  {deviceStatus.status.stateDirective && (
                    <div className="mt-4 p-3 bg-amber-50 rounded-md">
                      <p className="text-xs font-semibold text-amber-900 mb-1">State Directive</p>
                      <p className="text-sm text-amber-800">
                        Active: {deviceStatus.status.stateDirective.active ? 'Yes' : 'No'}
                      </p>
                      {deviceStatus.status.stateDirective.reason && (
                        <p className="text-sm text-amber-800 mt-1">
                          {deviceStatus.status.stateDirective.reason}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No status available. Configure device first.</p>
              )}
              <Button onClick={fetchDeviceStatus} disabled={loading} className="w-full mt-4" variant="outline">
                Refresh Status
              </Button>
            </CardContent>
          </Card>

          {/* Directive Controls */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Directive Controls</CardTitle>
              <CardDescription>Submit federal and state half-staff directives</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Federal Directive */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Federal Directive</h3>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="federalActive"
                      checked={federalActive}
                      onChange={(e) => setFederalActive(e.target.checked)}
                      className="rounded"
                    />
                    <Label htmlFor="federalActive">Active</Label>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="federalExpires">Expires At</Label>
                    <Input
                      type="datetime-local"
                      id="federalExpires"
                      value={federalExpires}
                      onChange={(e) => setFederalExpires(e.target.value)}
                      disabled={!federalActive}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="federalReason">Reason</Label>
                    <Textarea
                      id="federalReason"
                      value={federalReason}
                      onChange={(e) => setFederalReason(e.target.value)}
                      placeholder="Enter reason for half-staff order"
                      disabled={!federalActive}
                      rows={3}
                    />
                  </div>
                </div>

                {/* State Directive */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">State Directive</h3>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="stateActive"
                      checked={stateActive}
                      onChange={(e) => setStateActive(e.target.checked)}
                      className="rounded"
                    />
                    <Label htmlFor="stateActive">Active</Label>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stateExpires">Expires At</Label>
                    <Input
                      type="datetime-local"
                      id="stateExpires"
                      value={stateExpires}
                      onChange={(e) => setStateExpires(e.target.value)}
                      disabled={!stateActive}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stateReason">Reason</Label>
                    <Textarea
                      id="stateReason"
                      value={stateReason}
                      onChange={(e) => setStateReason(e.target.value)}
                      placeholder="Enter reason for half-staff order"
                      disabled={!stateActive}
                      rows={3}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 flex gap-4">
                <Button onClick={handleFetchDirectives} disabled={loading} variant="outline" className="flex-1">
                  Fetch Current Directives
                </Button>
                <Button onClick={handleSubmitDirectives} disabled={loading} className="flex-1">
                  Submit Directives
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
