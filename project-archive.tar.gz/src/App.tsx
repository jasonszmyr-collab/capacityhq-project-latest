import "./App.css";
import HomePage from "./components/HomePage";
import FlagControlTest from "./components/FlagControlTest";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <div>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/test" element={<FlagControlTest />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
